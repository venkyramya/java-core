/**
 * 
 */
/**
 * 
 */
module javapractice1 {
}